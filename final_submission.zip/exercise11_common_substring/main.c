
#include <stdio.h>
#include <string.h>

int common_substring(char *str1, char *str2) {
    int max = 0, end = 0;
    int n1=strlen(str1), n2=strlen(str2);

    for(int i=0;i<n1;i++){
        for(int j=0;j<n2;j++){
            int k=0;
            while(i+k<n1 && j+k<n2 && str1[i+k]==str2[j+k]) k++;
            if(k>max){ max=k; end=i+k-1; }
        }
    }

    if(max>0){
        for(int i=end-max+1;i<=end;i++) printf("%c", str1[i]);
        printf("\n");
    }
    return max;
}
