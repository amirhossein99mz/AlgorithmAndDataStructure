
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 100

typedef struct node_t {
    char *str;
    struct node_t *left;
    struct node_t *right;
} node_t;

int searchBST(node_t *root, char *key){
    if(!root) return 0;
    int cmp = strcmp(key, root->str);
    if(cmp==0) return 1;
    if(cmp<0) return searchBST(root->left,key);
    return searchBST(root->right,key);
}

int all_in(node_t *node, node_t *root[N]){
    for(int i=1;i<N;i++){
        if(root[i] && !searchBST(root[i], node->str))
            return 0;
    }
    return 1;
}

void inorder(node_t *node, node_t *root[N]){
    if(!node) return;
    inorder(node->left, root);
    if(all_in(node, root)) printf("%s\n", node->str);
    inorder(node->right, root);
}

void display_common(node_t *root[N]){
    if(!root || !root[0]) return;
    inorder(root[0], root);
}
