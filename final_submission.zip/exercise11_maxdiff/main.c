
#include <stdio.h>
#include <stdlib.h>

int max_diff(int **mat, int r, int c) {
    int max_difference = -1000000000;
    int best_i = 0, best_j = 0;

    int dirs[4][2] = {{1,1},{1,-1},{-1,1},{-1,-1}};

    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++){

            int min = mat[i][j];
            int max = mat[i][j];

            for(int d=0; d<4; d++){
                int x=i, y=j;
                while(x>=0 && x<r && y>=0 && y<c){
                    if(mat[x][y]>max) max=mat[x][y];
                    if(mat[x][y]<min) min=mat[x][y];
                    x+=dirs[d][0];
                    y+=dirs[d][1];
                }
            }

            if(max-min > max_difference){
                max_difference = max-min;
                best_i = i;
                best_j = j;
            }
        }
    }

    printf("(%d, %d)\n", best_i, best_j);
    return max_difference;
}
